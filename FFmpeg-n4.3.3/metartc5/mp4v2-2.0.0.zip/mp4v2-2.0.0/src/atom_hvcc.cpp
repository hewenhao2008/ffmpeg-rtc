/*
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * The Original Code is MPEG4IP.
 *
 * The Initial Developer of the Original Code is Cisco Systems Inc.
 * Portions created by Cisco Systems Inc. are
 * Copyright (C) Cisco Systems Inc. 2004.  All Rights Reserved.
 *
 * Contributor(s):
 *      Bill May wmay@cisco.com
 */

#include "src/impl.h"

namespace mp4v2 {
namespace impl {

///////////////////////////////////////////////////////////////////////////////

MP4HvcCAtom::MP4HvcCAtom(MP4File &file)
        : MP4Atom(file, "hvcC")
{
    AddProperty(new MP4BytesProperty(*this, "HEVCDecoderConfigurationRecord"));
}

void MP4HvcCAtom::Generate()
{
    MP4Atom::Generate();
}


void MP4HvcCAtom::Clone(MP4HvcCAtom *dstAtom)
{
    dstAtom->Generate();
    MP4BytesProperty* DstProp = (MP4BytesProperty *)(dstAtom->GetProperty(0));

    MP4BytesProperty* SrcProp = (MP4BytesProperty *)GetProperty(0);

    uint32_t size = SrcProp->GetValueSize();
    if (size < 1)
        return;
    uint8_t * temp = (uint8_t *)MP4Malloc(size);
    SrcProp->CopyValue(temp, size);
    DstProp->SetValue(temp, size);
    MP4Free(temp);
}

///////////////////////////////////////////////////////////////////////////////

}
} // namespace mp4v2::impl
