﻿#pragma once
#include <stdint.h>

int get_sequence_header(
    uint8_t *out_data,
    uint32_t* out_info,
    uint8_t *pps,
    uint16_t pps_len,
    uint8_t * sps,
    uint16_t sps_len,
    uint8_t * vps,
    uint16_t vps_len);
