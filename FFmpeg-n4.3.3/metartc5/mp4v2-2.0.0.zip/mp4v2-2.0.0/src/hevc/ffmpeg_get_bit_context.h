﻿#pragma once
#include <stdint.h>
#include <inttypes.h>
#include <limits.h>
#include <stddef.h>
#include <stdlib.h>
#define CONFIG_SAFE_BITSTREAM_READER 0
#define AV_INPUT_BUFFER_PADDING_SIZE    64
#define FFMAX(a,b)                  ((a) > (b) ? (a) : (b))
#define FFMIN(a,b)                  ((a) > (b) ? (b) : (a))
#ifndef UNCHECKED_BITSTREAM_READER
#define UNCHECKED_BITSTREAM_READER !CONFIG_SAFE_BITSTREAM_READER
#endif

typedef struct GetBitContext {
    const uint8_t *buffer, *buffer_end;
    int index;
    int size_in_bits;
    int size_in_bits_plus8;
} GetBitContext;

void skip_bits(GetBitContext *s, int n);

void skip_bits1(GetBitContext *gb);

void skip_bits_long(GetBitContext *s, int n);

unsigned int get_bits(GetBitContext *s, int n);

unsigned int get_bits1(GetBitContext *s);

unsigned int get_bits_long(GetBitContext *s, int n);

uint64_t get_bits64(GetBitContext *s, int n);

int init_get_bits8(GetBitContext *s, const uint8_t *buffer, int byte_size);

int get_bits_left(GetBitContext *gb);

int get_se_golomb(GetBitContext *gb);

int get_ue_golomb(GetBitContext *gb);

int get_ue_golomb_31(GetBitContext *gb);

unsigned int get_ue_golomb_long(GetBitContext *gb);

